"""
Main entry point for crispy-journey CLI.
"""


def main():
    """Main function for the crispy-journey CLI."""
    print("Welcome to Crispy Journey!")
    print("This is a minimal Python package.")
    return 0


if __name__ == "__main__":
    main()
