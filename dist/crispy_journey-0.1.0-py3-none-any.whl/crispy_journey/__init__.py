"""
Crispy Journey - A fully automated journey
"""

__version__ = "0.1.0"

def hello():
    """Return a greeting message."""
    return "Hello from crispy-journey!"

def main():
    """Main entry point for the package."""
    print(hello())
    return True